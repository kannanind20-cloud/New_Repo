@echo off
REM ------------------------------------------------------------------
REM Copies new builds from the share to OneDrive. Run hourly by Task Scheduler.
REM Only these folders are synced: Install, Update, VWSC
REM Does NOT delete anything on either side (no /MIR, no /PURGE).
REM ------------------------------------------------------------------

set "SRC=\\172.25.136.6\share\Velocity\3.9.1 Builds"
set "DST=%USERPROFILE%\OneDrive - Hirsch Secure USA\Velocity Builds\3.9.1 Builds"
set "LOG=C:\New10\New\sync_to_onedrive.log"

echo ===== %date% %time% ===== >> "%LOG%"

set "FAILED=0"
for %%F in (Install Update VWSC) do (
    if not exist "%DST%\%%F" mkdir "%DST%\%%F"
    robocopy "%SRC%\%%F" "%DST%\%%F" /E /R:2 /W:5 /XF *.tmp *.crdownload *.part /NP /NDL /LOG+:"%LOG%"
    if errorlevel 8 (
        echo SYNC FAILED for %%F >> "%LOG%"
        set "FAILED=1"
    )
)

if "%FAILED%"=="1" exit /b 1
exit /b 0