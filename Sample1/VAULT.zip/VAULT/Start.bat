@echo off
REM Change this to the folder where your Python script is located
cd /d "C:\New10\New"

REM Run the Python script using the Python launcher
py "wholemerged-4.py"

REM pause   <-- remove this line
